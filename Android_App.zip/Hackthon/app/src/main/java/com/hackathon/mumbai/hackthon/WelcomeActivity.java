package com.hackathon.mumbai.hackthon;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.StrictMode;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.net.*;
import java.io.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class WelcomeActivity extends AppCompatActivity {
    Button login, signin;
    EditText username_login,password_login;
    @Override
    protected  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        login = (Button) findViewById(R.id.login);
        signin = (Button) findViewById(R.id.signin);
        username_login=(EditText)findViewById(R.id.username_login);
        password_login=(EditText)findViewById(R.id.password_login);
    }
    public void dosomething(View v)
    {

        if (v.getId() == R.id.login)
        {
            Intent i = new Intent(WelcomeActivity.this, MenuActivity.class);
            startActivity(i);

        }
        if (v.getId() == R.id.signin)
        {
            Intent i = new Intent(WelcomeActivity.this, SignInActivity.class);
            startActivity(i);
        }
    }
}