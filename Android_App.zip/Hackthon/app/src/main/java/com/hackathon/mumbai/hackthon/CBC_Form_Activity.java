package com.hackathon.mumbai.hackthon;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class CBC_Form_Activity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    Spinner spin;
    Button cbcsubmit;

    String[] bankNames={"O +","0 -","A +","A -","B +","B -","AB +", "AB -"};
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cbc__form_);
        cbcsubmit=(Button)findViewById(R.id.cbcsubmit);
        spin = (Spinner) findViewById(R.id.simpleSpinner);
        spin.setOnItemSelectedListener(this);

        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,bankNames);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);


    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id)
    {
        Toast.makeText(getApplicationContext(), bankNames[position], Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0)
    {
// TODO Auto-generated method stub

    }

    public void dosomething(View v)
    {
        if (v.getId() == R.id.cbcsubmit)
        {
            Intent i = new Intent(CBC_Form_Activity.this, GraphActivity.class);
            startActivity(i);
        }

    }
}
