package com.hackathon.mumbai.hackthon;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.kosalgeek.android.photoutil.MainActivity;

import java.util.ArrayList;

public class GraphActivity extends AppCompatActivity {
    public static String TAG="MainActivity";
    private float[] yData={25.3f,10.6f,66.76f,44.32f,46.01f,16.89f,23.9f};
    private String[]xData={"Sachin","Ankit","Pritesh","Akash","Adarsh","Sonu","Monu"};
    PieChart pieChart;
    int k,pos1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);
        Log.d(TAG,"onCreate:starting to create chart");
        pieChart=(PieChart)findViewById(R.id.pie_chart);
       // pieChart.setDescription("Sales by employee(in thousands $)");
        pieChart.setRotationEnabled(true);
        //pieChart.setUsePercentValues(true);
        //pieChart.setHoleColor(Color.BLUE);
        //pieChart.setCenterTextColor(Color.BLACK);
        pieChart.setHoleRadius(25f);
        pieChart.setTransparentCircleAlpha(0);
        pieChart.setCenterText("Super cool Chart");
        pieChart.setCenterTextSize(10);
        //pieChart.setDrawEntryLabels(true);
        //pieChart.setEntryLabelTextSize(20);


        //now add data to chart
        addDataSet();
        pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener()
        {
            @Override
            public void onValueSelected(Entry e, Highlight h)
            {
                Log.d(TAG,"ON ValueSelected: value selected from chart.");
                Log.d(TAG,"ON ValueSelected."+e);
                Log.d(TAG,"ON ValueSelected"+h.toString());
               // pos1=new e.toString.indexOf("(sum:" );
                String sales=e.toString().substring(pos1+7);
                for(int i=0; i<yData.length; i++)
                {
                    if((yData[i] == Float.parseFloat(sales)))
                    {

                        pos1=k;
                        break;
                    }
                }
                String employee=xData[pos1+1];
                Toast.makeText(GraphActivity.this,"Employee" + employee+ "\n" +"Sales:$" + sales + "K",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected()
            {

            }
        });

    }

    private void addDataSet()
    {
        ArrayList<PieEntry>yEntrys=new ArrayList<>();
        ArrayList<String>xEntrys=new ArrayList<>();

        //for y data
        for(int i=0; i<yData.length;i++)
        {
            yEntrys.add(new PieEntry(yData[i],i));
        }
        // for x data
        for(int i=0; i<xData.length;i++)
        {
            xEntrys.add(xData[i]);
        }

        //create data set
        PieDataSet pieDataSet=new PieDataSet(yEntrys,"Enployee Sales");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);

        //add color to databasee

        ArrayList<Integer>color=new ArrayList<>();
        color.add(Color.GRAY);
        color.add(Color.BLUE);
        color.add(Color.RED);
        color.add(Color.GREEN);
        color.add(Color.CYAN);
        color.add(Color.MAGENTA);

        //now add legend to chart
        Legend legend=pieChart.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.setPosition(Legend.LegendPosition.LEFT_OF_CHART);

        //now create pie data object
        PieData pieData=new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieChart.invalidate();
    }




}
