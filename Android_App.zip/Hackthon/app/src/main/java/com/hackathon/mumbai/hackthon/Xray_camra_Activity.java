package com.hackathon.mumbai.hackthon;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.kosalgeek.android.photoutil.CameraPhoto;
import com.kosalgeek.android.photoutil.ImageLoader;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Xray_camra_Activity extends AppCompatActivity {
    private final String TAG=this.getClass().getName();
    ImageView camera,iv_image;
    CameraPhoto cameraphoto;
    final int CAMERA_REQUEST=13323;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xray_camra_);

        cameraphoto=new CameraPhoto(getApplicationContext());
        camera=(ImageView)findViewById(R.id.camera);
        iv_image=(ImageView)findViewById(R.id.iv_image);

        camera.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                try
                {
                    startActivityForResult(cameraphoto.takePhotoIntent(),CAMERA_REQUEST);
                    cameraphoto.addToGallery();
                }
                catch (IOException e)
                {
                    Toast.makeText(getApplicationContext(),"Something Wrong While Taking Photo...",Toast.LENGTH_LONG).show();
                }

            }
        });


    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
            if(resultCode==RESULT_OK)
            {
                if(requestCode==CAMERA_REQUEST)
                {
                    String photoPath=cameraphoto.getPhotoPath();
                    try
                    {
                        Bitmap bitmap= ImageLoader.init().from(photoPath).requestSize(512,512).getBitmap();
                        iv_image.setImageBitmap(bitmap);
                    }
                    catch(FileNotFoundException e)
                    {
                        Toast.makeText(getApplicationContext(),"Something Wrong While Loading Photo...",Toast.LENGTH_LONG).show();
                    }

                }
            }

    }
}
