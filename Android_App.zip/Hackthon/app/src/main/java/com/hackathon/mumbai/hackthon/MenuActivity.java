package com.hackathon.mumbai.hackthon;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {
    Button CBC,xray;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        CBC=(Button)findViewById(R.id.CBC);
        xray=(Button)findViewById(R.id.xray);

    }

    public void dosomething(View v)
    {
        if(v.getId()==R.id.CBC)
        {
            Intent i=new Intent(MenuActivity.this, CBC_Form_Activity.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.xray)
        {
            Intent i=new Intent(MenuActivity.this, Xray_camra_Activity.class);
            startActivity(i);
        }


    }

}
